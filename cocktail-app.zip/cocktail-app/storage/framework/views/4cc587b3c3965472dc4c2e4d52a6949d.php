<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'cocktail' => [],
    'showFavoriteButton' => true
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'cocktail' => [],
    'showFavoriteButton' => true
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="modal fade" id="cocktailModal-<?php echo e($cocktail['id']); ?>" tabindex="-1" aria-labelledby="cocktailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="cocktailModalLabel">
                    <i class="fas fa-cocktail me-2"></i><?php echo e($cocktail['name']); ?>

                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- Columna izquierda - Imagen e información básica -->
                    <div class="col-md-5">
                        <div class="sticky-top" style="top: 20px;">
                            <img src="<?php echo e($cocktail['image']); ?>" class="img-fluid rounded mb-3 shadow" alt="<?php echo e($cocktail['name']); ?>" style="max-height: 300px; width: 100%; object-fit: cover;">

                            <div class="card mb-3">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Información Básica</h6>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-tag me-2"></i><strong>Categoría:</strong></span>
                                            <span class="badge bg-primary rounded-pill"><?php echo e($cocktail['category']); ?></span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-glass-whiskey me-2"></i><strong>Tipo de Vaso:</strong></span>
                                            <span class="badge bg-success rounded-pill"><?php echo e($cocktail['glass']); ?></span>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span><i class="fas fa-wine-bottle me-2"></i><strong>Tipo de Bebida:</strong></span>
                                            <span class="badge bg-info rounded-pill"><?php echo e($cocktail['type']); ?></span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Columna derecha - Ingredientes y preparación -->
                    <div class="col-md-7">
                        <div class="card mb-3">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-list-ul me-2"></i>Ingredientes</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead class="table-light">
                                            <tr>
                                                <th width="60%">Ingrediente</th>
                                                <th width="40%">Cantidad</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $cocktail['ingredients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $parts = explode(' - ', $ingredient, 2);
                                            $ingredientName = $parts[0] ?? '';
                                            $measure = $parts[1] ?? 'Al gusto';
                                            ?>
                                            <tr>
                                                <td><?php echo e($ingredientName); ?></td>
                                                <td><?php echo e($measure); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header bg-light">
                                <h6 class="mb-0"><i class="fas fa-list-ol me-2"></i>Preparación</h6>
                            </div>
                            <div class="card-body">
                                <div class="preparation-steps">
                                    <?php
                                    // Dividir las instrucciones en pasos si hay números
                                    $steps = preg_split('/(?<=\d\.)\s+/', $cocktail['instructions']);
                                    ?>

                                    <?php if(count($steps) > 1): ?>
                                    <ol>
                                        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(trim($step)): ?>
                                        <li><?php echo e($step); ?></li>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                    <?php else: ?>
                                    <p><?php echo e($cocktail['instructions']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-2"></i>Cerrar
                </button>
                
                <?php if($showFavoriteButton): ?>
                <form action="<?php echo e(route('cocktails.favorite')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="cocktail_id" value="<?php echo e($cocktail['id']); ?>">
                    <input type="hidden" name="name" value="<?php echo e($cocktail['name']); ?>">
                    <input type="hidden" name="category" value="<?php echo e($cocktail['category']); ?>">
                    <input type="hidden" name="glass_type" value="<?php echo e($cocktail['glass']); ?>">
                    <input type="hidden" name="instructions" value="<?php echo e($cocktail['instructions']); ?>">
                    <input type="hidden" name="image_url" value="<?php echo e($cocktail['image']); ?>">

                    <?php $__currentLoopData = $cocktail['ingredients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="ingredients[]" value="<?php echo e($ingredient); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-bookmark me-2"></i>Guardar como favorito
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\farfa.DESKTOP-7L3C2A6\OneDrive\Escritorio\cocktail-app\cocktail-app\resources\views/components/modal-cocktail.blade.php ENDPATH**/ ?>