

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('styles/cocktails/card.style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Cócteles'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <form method="GET" action="<?php echo e(route('cocktails.index')); ?>" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Buscar cócteles..." value="<?php echo e(request('search', '')); ?>">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
    </form>

    <h1 class="my-4">🍸 <?php echo e($randomView ? "Descubre tu nuevo cóctel" : "Lista de cócteles"); ?></h1>

    <?php if($cocktails->isEmpty()): ?>
    <div class="alert alert-info">No se encontraron cócteles con ese nombre.</div>
    <?php else: ?>
    <div class="row">
        <?php $__currentLoopData = $cocktails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cocktail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card card-cocktail h-100">
                <img src="<?php echo e($cocktail['image']); ?>" class="card-img-top" alt="<?php echo e($cocktail['name']); ?>" style="height: 200px; object-fit: cover;">
                <form action="<?php echo e(route('cocktails.favorite')); ?>" method="POST" class="favorite-form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="cocktail_id" value="<?php echo e($cocktail['id']); ?>">
                    <input type="hidden" name="name" value="<?php echo e($cocktail['name']); ?>">
                    <input type="hidden" name="category" value="<?php echo e($cocktail['category']); ?>">
                    <input type="hidden" name="glass_type" value="<?php echo e($cocktail['glass']); ?>">
                    <input type="hidden" name="instructions" value="<?php echo e($cocktail['instructions']); ?>">
                    <input type="hidden" name="image_url" value="<?php echo e($cocktail['image']); ?>">

                    <?php $__currentLoopData = $cocktail['ingredients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="ingredients[]" value="<?php echo e($ingredient); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <button class="float-button-favorite">
                        <i class="fas fa-bookmark"></i>
                    </button>
                </form>

                <div class="card-body">
                    <h5 class="card-title"><?php echo e($cocktail['name']); ?></h5>
                    <p class="card-text"><strong>Categoría:</strong> <?php echo e($cocktail['category']); ?></p>

                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#cocktailModal-<?php echo e($cocktail['id']); ?>">
                        Ver Detalles Completos
                    </button>
                </div>
            </div>
        </div>

        <!-- Modal para cada cóctel -->
        <div class="modal fade" id="cocktailModal-<?php echo e($cocktail['id']); ?>" tabindex="-1" aria-labelledby="cocktailModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="cocktailModalLabel">
                            <i class="fas fa-cocktail me-2"></i><?php echo e($cocktail['name']); ?>

                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <!-- Columna izquierda - Imagen e información básica -->
                            <div class="col-md-5">
                                <div class="sticky-top" style="top: 20px;">
                                    <img src="<?php echo e($cocktail['image']); ?>" class="img-fluid rounded mb-3 shadow" alt="<?php echo e($cocktail['name']); ?>" style="max-height: 300px; width: 100%; object-fit: cover;">

                                    <div class="card mb-3">
                                        <div class="card-header bg-light">
                                            <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Información Básica</h6>
                                        </div>
                                        <div class="card-body">
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span><i class="fas fa-tag me-2"></i><strong>Categoría:</strong></span>
                                                    <span class="badge bg-primary rounded-pill"><?php echo e($cocktail['category']); ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span><i class="fas fa-glass-whiskey me-2"></i><strong>Tipo de Vaso:</strong></span>
                                                    <span class="badge bg-success rounded-pill"><?php echo e($cocktail['glass']); ?></span>
                                                </li>
                                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                                    <span><i class="fas fa-wine-bottle me-2"></i><strong>Tipo de Bebida:</strong></span>
                                                    <span class="badge bg-info rounded-pill"><?php echo e($cocktail['type']); ?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Columna derecha - Ingredientes y preparación -->
                            <div class="col-md-7">
                                <div class="card mb-3">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0"><i class="fas fa-list-ul me-2"></i>Ingredientes</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-sm">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th width="60%">Ingrediente</th>
                                                        <th width="40%">Cantidad</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $cocktail['ingredients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                    $parts = explode(' - ', $ingredient, 2);
                                                    $ingredientName = $parts[0] ?? '';
                                                    $measure = $parts[1] ?? 'Al gusto';
                                                    ?>
                                                    <tr>
                                                        <td><?php echo e($ingredientName); ?></td>
                                                        <td><?php echo e($measure); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <div class="card">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0"><i class="fas fa-list-ol me-2"></i>Preparación</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="preparation-steps">
                                            <?php
                                            // Dividir las instrucciones en pasos si hay números
                                            $steps = preg_split('/(?<=\d\.)\s+ /', $cocktail['instructions']);
                                            ?>

                                            <?php if(count($steps)> 1): ?>
                                            <ol>
                                                <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($step)): ?>
                                                <li><?php echo e($step); ?></li>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ol>
                                            <?php else: ?>
                                            <p><?php echo e($cocktail['instructions']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-2"></i>Cerrar
                        </button>
                        <form action="<?php echo e(route('cocktails.favorite')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="cocktail_id" value="<?php echo e($cocktail['id']); ?>">
                            <input type="hidden" name="name" value="<?php echo e($cocktail['name']); ?>">
                            <input type="hidden" name="category" value="<?php echo e($cocktail['category']); ?>">
                            <input type="hidden" name="glass_type" value="<?php echo e($cocktail['glass']); ?>">
                            <input type="hidden" name="instructions" value="<?php echo e($cocktail['instructions']); ?>">
                            <input type="hidden" name="image_url" value="<?php echo e($cocktail['image']); ?>">

                            <?php $__currentLoopData = $cocktail['ingredients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="ingredients[]" value="<?php echo e($ingredient); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-bookmark me-2"></i>Guardar como favorito
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    <?php if(session('success')): ?>
    Swal.fire({
        icon: 'success',
        title: 'Cóctel agregado a favoritos',
        text: '¡El cóctel se ha añadido a tu lista de favoritos!',
        confirmButtonText: '¡Genial!'
    });
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\farfa.DESKTOP-7L3C2A6\OneDrive\Escritorio\cocktail-app\cocktail-app\resources\views/cocktails/index.blade.php ENDPATH**/ ?>