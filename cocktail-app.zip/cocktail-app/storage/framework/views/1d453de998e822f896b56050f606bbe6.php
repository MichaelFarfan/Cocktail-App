<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel - <?php echo $__env->yieldContent('title', 'Inicio'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('styles/layout/sidebar.loyaut.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <?php if(auth()->guard()->check()): ?>
        <div class="sidebar p-3 border-end">
            <h4 class="mb-4">Mi panel</h4>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                        <i class="fas fa-tachometer-alt fa-icon"></i>
                        <span class="label ms-2">Resumen</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center <?php echo e(request()->is('cocktails*') ? 'active' : ''); ?>" href="<?php echo e(route('cocktails.index')); ?>">
                        <i class="fas fa-cocktail fa-icon"></i>
                        <span class="label ms-2">Cócteles</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center <?php echo e(request()->is('favorites') ? 'active' : ''); ?>" href="<?php echo e(route('favorites.index')); ?>">
                        <i class="fas fa-heart fa-icon"></i>
                        <span class="label ms-2">Mis favoritos</span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center <?php echo e(request()->is('perfil*') ? 'active' : ''); ?>" href="<?php echo e(route('perfil.edit')); ?>">
                        <i class="fas fa-user fa-icon"></i>
                        <span class="label ms-2">Mi perfil</span>
                    </a>
                </li>

                <?php if(auth()->user()->role_id === 1): ?>
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center <?php echo e(request()->is('usuarios*') ? 'active' : ''); ?>" href="<?php echo e(route('usuarios.index')); ?>">
                        <i class="fas fa-users fa-icon"></i>
                        <span class="label ms-2">Panel de usuarios</span>
                    </a>
                </li>
                <?php endif; ?>

                <li class="nav-item mt-3">
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline-danger w-100 d-flex align-items-center justify-content-center">
                            <i class="fas fa-sign-out-alt me-2"></i>
                            <span class="label">Cerrar sesión</span>
                        </button>
                    </form>
                </li>
            </ul>
        </div>
        <?php endif; ?>

        <!-- Contenido principal -->
        <div class="flex-grow-1 p-4">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\farfa.DESKTOP-7L3C2A6\OneDrive\Escritorio\cocktail-app\cocktail-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>